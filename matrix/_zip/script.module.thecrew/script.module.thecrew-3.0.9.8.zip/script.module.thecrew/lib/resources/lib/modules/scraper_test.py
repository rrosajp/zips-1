# -*- coding: utf-8 -*-

'''
 ***********************************************************
 * The Crew Add-on - Scraper Testing Module
 *
 * @file scraper_test.py
 * @package script.module.thecrew
 *
 * @copyright (c) 2026, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 * Provides connectivity testing for scrapers to help diagnose
 * geo-blocking and connection issues.
 ***********************************************************
'''

import os
import re
import time
import json
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from urllib.parse import urlparse
import sqlite3 as database

from resources.lib.modules import control
from resources.lib.modules import client
from resources.lib.modules.crewruntime import c

INTERNAL_SCRAPER_PREFIX = 'resources.lib.scrapers.'
MIN_TEST_WORKERS = 5
MAX_TEST_WORKERS = 10


def is_internal_scraper(module_name):
    """True for Crew-owned scrapers under resources.lib.scrapers/."""
    return bool(module_name) and str(module_name).startswith(INTERNAL_SCRAPER_PREFIX)


PACK_SCRAPER_PREFIXES = (
    'cocoscrapers.',
    'gearsscrapers.',
    'viperscrapers.',
)


def is_pack_scraper(module_name):
    """True for external scraper packs integrated into Crew source searches."""
    module_name = str(module_name or '')
    return any(module_name.startswith(prefix) for prefix in PACK_SCRAPER_PREFIXES)


def is_user_toggle_eligible(module_name):
    """Scrapers that can be user-disabled via Scraper Status / registry."""
    return is_internal_scraper(module_name) or is_pack_scraper(module_name)


def is_auto_disable_candidate(scraper):
    """
    Scrapers to turn off with Auto Disable Blocked:
    - internal or pack scrapers (e.g. zilean, prowlarr)
    - not already user-disabled, code-disabled, or defunct
    - not fully working (includes hard-blocked and accessible-but-failing)
    """
    module = scraper.get('module', '')
    if not is_user_toggle_eligible(module):
        return False
    if scraper.get('user_disabled'):
        return False
    if scraper.get('disabled') or scraper.get('defunct'):
        return False
    return not scraper.get('working')


class ScraperTester:
    """Test scraper connectivity and cache results."""

    def __init__(self):
        self.cache_file = control.cacheFile
        self.cache_table = 'scraper_status'
        self._ensure_cache_table()

    def _ensure_cache_table(self):
        """Ensure the scraper status cache table exists."""
        try:
            control.makeFile(control.dataPath)
            dbcon = database.connect(self.cache_file)
            dbcur = dbcon.cursor()
            dbcur.execute('''
                CREATE TABLE IF NOT EXISTS scraper_status (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scraper_name TEXT UNIQUE,
                    category TEXT,
                    module_name TEXT,
                    accessible INTEGER,
                    working INTEGER,
                    disabled INTEGER,
                    defunct INTEGER,
                    pack_capable INTEGER,
                    response_time REAL,
                    error TEXT,
                    last_tested INTEGER,
                    user_disabled INTEGER DEFAULT 0
                )
            ''')
            try:
                dbcur.execute('ALTER TABLE scraper_status ADD COLUMN user_disabled INTEGER DEFAULT 0')
            except Exception:
                pass
            dbcon.commit()
            dbcur.close()
            dbcon.close()
        except Exception as e:
            c.log(f'[ScraperTest] Error creating cache table: {e}', 1)

    def _test_worker_count(self):
        """Parallel connectivity test workers (5–10, derived from max.threads)."""
        try:
            raw = int(c.get_setting('max.threads') or 25)
        except (TypeError, ValueError):
            raw = 25
        return max(MIN_TEST_WORKERS, min(MAX_TEST_WORKERS, max(1, raw // 3)))

    def _userdata_settings_path(self):
        appdata = os.environ.get('APPDATA') or os.path.expanduser('~')
        return os.path.join(appdata, 'Kodi', 'userdata', 'addon_data', 'plugin.video.thecrew', 'settings.xml')

    def _load_user_disabled_map(self):
        """module_name -> user_disabled (0/1) from current cache."""
        mapping = {}
        try:
            dbcon = database.connect(self.cache_file)
            dbcur = dbcon.cursor()
            dbcur.execute('SELECT module_name, user_disabled FROM scraper_status')
            for module_name, user_disabled in dbcur.fetchall():
                if module_name:
                    mapping[module_name] = int(user_disabled or 0)
            dbcur.close()
            dbcon.close()
        except Exception as exc:
            c.log(f'[ScraperTest] Could not load user_disabled map: {exc}', 1)
        return mapping

    def migrate_legacy_provider_settings(self):
        """
        One-time import of provider.<scraper>=false from userdata into user_disabled.
        """
        path = self._userdata_settings_path()
        if not os.path.isfile(path):
            return 0
        try:
            root = ET.parse(path).getroot()
        except Exception:
            return 0

        migrated = 0
        for setting in root.findall('setting'):
            sid = setting.attrib.get('id') or ''
            if not sid.startswith('provider.'):
                continue
            value = (setting.text or setting.attrib.get('default') or '').strip().lower()
            if value != 'false':
                continue
            short = sid.replace('provider.', '', 1)
            module_name = f'{INTERNAL_SCRAPER_PREFIX}{short}'
            if self.set_user_disabled(module_name, True, scraper_name=short.upper()):
                migrated += 1

        if migrated:
            c.log(f'[ScraperTest] Migrated {migrated} legacy provider.* disable(s) to user_disabled')
        return migrated

    def iter_auto_disable_candidates(self, status_data=None):
        """
        Internal and pack scrapers that are not working (blocked or failing)
        and not already off via code, defunct flag, or user toggle.
        """
        status = status_data if status_data is not None else self.load_status()
        if not status:
            return
        for bucket in ('direct', 'torrent', 'usenet'):
            for scraper in status.get(bucket, []):
                if is_auto_disable_candidate(scraper):
                    yield scraper

    def auto_disable_blocked_internal(self, status_data=None):
        """Set user_disabled on all non-working eligible scrapers. Returns count disabled."""
        disabled = 0
        for scraper in self.iter_auto_disable_candidates(status_data):
            module = scraper.get('module', '')
            name = scraper.get('name')
            if self.set_user_disabled(module, True, scraper_name=name):
                disabled += 1
        return disabled

    def set_user_disabled(self, module_name, disabled=True, scraper_name=None):
        """Set user_disabled for an internal or pack scraper module."""
        if not is_user_toggle_eligible(module_name):
            return False

        flag = 1 if disabled else 0
        name = scraper_name or module_name.split('.')[-1].replace('_', ' ').upper()
        category = 'torrent' if 'torrent' in module_name.lower() else 'direct'
        try:
            dbcon = database.connect(self.cache_file)
            dbcur = dbcon.cursor()
            dbcur.execute('SELECT id FROM scraper_status WHERE module_name = ?', (module_name,))
            row = dbcur.fetchone()
            if row:
                dbcur.execute(
                    'UPDATE scraper_status SET user_disabled = ? WHERE module_name = ?',
                    (flag, module_name),
                )
            else:
                dbcur.execute('''
                    INSERT INTO scraper_status
                    (scraper_name, category, module_name, accessible, working,
                     disabled, defunct, pack_capable, response_time, error,
                     last_tested, user_disabled)
                    VALUES (?, ?, ?, 0, 0, 0, 0, 0, NULL, NULL, 0, ?)
                ''', (name, category, module_name, flag))
            dbcon.commit()
            dbcur.close()
            dbcon.close()
            try:
                from resources.lib.modules.scraper_registry import get_registry
                get_registry().invalidate()
            except Exception:
                pass
            return True
        except Exception as exc:
            c.log(f'[ScraperTest] set_user_disabled failed for {module_name}: {exc}', 1)
            return False

    def _scraper_category(self, module_name):
        if 'torrent' in module_name.lower() or 'en_tor' in module_name.lower():
            return 'torrent'
        if 'usenet' in module_name.lower():
            return 'usenet'
        return 'direct'

    def _organize_results(self, results, current_time):
        organized = {
            'direct': [],
            'torrent': [],
            'usenet': [],
            'summary': {},
        }
        total_count = working_count = accessible_count = blocked_count = 0
        disabled_count = user_disabled_count = 0

        for result in results:
            cat = result['category']
            if cat == 'torrent':
                organized['torrent'].append(result)
            elif cat == 'usenet':
                organized['usenet'].append(result)
            else:
                organized['direct'].append(result)

            total_count += 1
            if result.get('user_disabled'):
                user_disabled_count += 1
            if result['disabled']:
                disabled_count += 1
            elif result['working']:
                working_count += 1
            elif result['accessible']:
                accessible_count += 1
            else:
                blocked_count += 1

        organized['summary'] = {
            'total': total_count,
            'working': working_count,
            'accessible': accessible_count,
            'blocked': blocked_count,
            'disabled': disabled_count,
            'user_disabled': user_disabled_count,
            'last_updated': datetime.fromtimestamp(current_time).isoformat(),
        }
        return organized

    def _persist_results(self, results, user_disabled_map, current_time):
        try:
            dbcon = database.connect(self.cache_file)
            dbcur = dbcon.cursor()
            dbcur.execute('DELETE FROM scraper_status')
            for result in results:
                module_name = result['module']
                user_flag = user_disabled_map.get(module_name, int(result.get('user_disabled', 0)))
                dbcur.execute('''
                    INSERT OR REPLACE INTO scraper_status
                    (scraper_name, category, module_name, accessible, working,
                     disabled, defunct, pack_capable, response_time, error,
                     last_tested, user_disabled)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    result['name'],
                    result['category'],
                    module_name,
                    1 if result['accessible'] else 0,
                    1 if result['working'] else 0,
                    1 if result['disabled'] else 0,
                    1 if result['defunct'] else 0,
                    1 if result['pack_capable'] else 0,
                    result['response_time'],
                    result['error'],
                    current_time,
                    user_flag,
                ))
            dbcon.commit()
            dbcur.close()
            dbcon.close()
        except Exception as exc:
            c.log(f'[ScraperTest] Error persisting results: {exc}', 1)

    def _evaluate_scraper(self, module_name, scraper_obj, pack_flags):
        """Build a test result dict for one scraper (thread-safe)."""
        cocoscrapers_enabled, gearsscrapers_enabled, viperscrapers_enabled = pack_flags
        name = getattr(scraper_obj, 'name', module_name.split('.')[-1])
        category = self._scraper_category(module_name)

        pack_disabled = False
        if 'cocoscrapers' in module_name.lower() and not cocoscrapers_enabled:
            pack_disabled = True
        elif 'gearsscrapers' in module_name.lower() and not gearsscrapers_enabled:
            pack_disabled = True
        elif 'viperscrapers' in module_name.lower() and not viperscrapers_enabled:
            pack_disabled = True

        disabled = pack_disabled or getattr(scraper_obj, 'disabled', False)
        defunct = getattr(scraper_obj, 'defunct', False)
        pack_capable = getattr(scraper_obj, 'pack_capable', False)

        accessible = False
        working = False
        response_time = None
        error = None

        if disabled:
            error = 'DISABLED'
        elif defunct:
            error = 'Defunct'
        else:
            accessible, working, response_time, error = self._test_scraper_connectivity(
                scraper_obj, name
            )

        return {
            'name': name,
            'category': category,
            'module': module_name,
            'accessible': accessible,
            'working': working,
            'disabled': disabled,
            'defunct': defunct,
            'pack_capable': pack_capable,
            'response_time': response_time,
            'error': error,
            'internal': is_internal_scraper(module_name),
            'user_disabled': 0,
        }

    def load_status(self):
        """Load cached scraper status from database."""
        try:
            self.migrate_legacy_provider_settings()

            dbcon = database.connect(self.cache_file)
            dbcur = dbcon.cursor()
            dbcur.execute('SELECT * FROM scraper_status')
            rows = dbcur.fetchall()
            colnames = [d[0] for d in dbcur.description] if dbcur.description else []
            dbcur.close()
            dbcon.close()

            if not rows:
                return None

            result = {
                'direct': [],
                'torrent': [],
                'usenet': [],
                'summary': {},
            }

            total = working = accessible = blocked = disabled = 0
            user_disabled = 0
            last_updated = 0

            for row in rows:
                data = dict(zip(colnames, row)) if colnames else {}
                if not colnames:
                    data = {
                        'scraper_name': row[1],
                        'category': row[2],
                        'module_name': row[3],
                        'accessible': row[4],
                        'working': row[5],
                        'disabled': row[6],
                        'defunct': row[7],
                        'pack_capable': row[8],
                        'response_time': row[9],
                        'error': row[10],
                        'last_tested': row[11],
                        'user_disabled': row[12] if len(row) > 12 else 0,
                    }

                module_name = data.get('module_name') or ''
                scraper = {
                    'name': data.get('scraper_name'),
                    'category': data.get('category'),
                    'module': module_name,
                    'accessible': bool(data.get('accessible')),
                    'working': bool(data.get('working')),
                    'disabled': bool(data.get('disabled')),
                    'defunct': bool(data.get('defunct')),
                    'pack_capable': bool(data.get('pack_capable')),
                    'response_time': data.get('response_time'),
                    'error': data.get('error'),
                    'user_disabled': bool(data.get('user_disabled')),
                    'internal': is_internal_scraper(module_name),
                }

                tested_at = data.get('last_tested') or 0
                if tested_at and tested_at > last_updated:
                    last_updated = tested_at

                category = data.get('category') or 'direct'
                if category.startswith('torrent') or category == 'en_tor':
                    result['torrent'].append(scraper)
                elif category.startswith('usenet'):
                    result['usenet'].append(scraper)
                else:
                    result['direct'].append(scraper)

                total += 1
                if scraper['user_disabled']:
                    user_disabled += 1
                if scraper['disabled']:
                    disabled += 1
                elif scraper['working']:
                    working += 1
                elif scraper['accessible']:
                    accessible += 1
                else:
                    blocked += 1

            result['summary'] = {
                'total': total,
                'working': working,
                'accessible': accessible,
                'blocked': blocked,
                'disabled': disabled,
                'user_disabled': user_disabled,
                'last_updated': datetime.fromtimestamp(last_updated).isoformat() if last_updated else None,
            }

            return result

        except Exception as e:
            c.log(f'[ScraperTest] Error loading status: {e}', 1)
            return None

    def is_cache_valid(self, max_age_hours=24):
        """Check if cached data is still valid."""
        try:
            dbcon = database.connect(self.cache_file)
            dbcur = dbcon.cursor()
            dbcur.execute('SELECT MAX(last_tested) FROM scraper_status')
            result = dbcur.fetchone()
            dbcur.close()
            dbcon.close()

            if not result or not result[0]:
                return False

            age_seconds = time.time() - result[0]
            max_age_seconds = max_age_hours * 3600
            return age_seconds < max_age_seconds

        except Exception as e:
            c.log(f'[ScraperTest] Error checking cache validity: {e}', 1)
            return False

    def test_all_scrapers(self, test_type='connectivity', progress_callback=None):
        """
        Test all scrapers for connectivity (parallel, 5–10 workers).

        :param test_type: Type of test - 'connectivity' checks if domain is reachable
        :param progress_callback: Callback function(current, total, name) for progress
        :return: Dictionary with test results organized by category
        """
        c.log('[ScraperTest] Starting scraper connectivity tests')

        cocoscrapers_enabled = c.get_setting('cocoscrapers.enabled') == 'true'
        gearsscrapers_enabled = c.get_setting('gearsscrapers.enabled') == 'true'
        viperscrapers_enabled = c.get_setting('viperscrapers.enabled') == 'true'
        pack_flags = (cocoscrapers_enabled, gearsscrapers_enabled, viperscrapers_enabled)

        c.log(
            f'[ScraperTest] Scraper pack settings: coco={cocoscrapers_enabled}, '
            f'gears={gearsscrapers_enabled}, viper={viperscrapers_enabled}'
        )

        try:
            from resources.lib.sources import sources as load_sources
            source_list = load_sources()
        except Exception as e:
            c.log(f'[ScraperTest] Error loading scrapers: {e}', 1)
            return None

        if not source_list:
            c.log('[ScraperTest] No scrapers found', 1)
            return None

        workers = self._test_worker_count()
        total = len(source_list)
        c.log(f'[ScraperTest] Testing {total} scrapers with {workers} parallel workers')

        user_disabled_map = self._load_user_disabled_map()
        self.migrate_legacy_provider_settings()
        for module_name, flag in list(user_disabled_map.items()):
            if flag:
                continue
            try:
                short = module_name.split('.')[-1]
                legacy = c.get_setting('provider.' + short)
                if legacy == 'false':
                    user_disabled_map[module_name] = 1
            except Exception:
                pass

        current_time = int(time.time())
        results = []
        cancelled = False
        completed = 0

        def _run_one(item):
            module_name, scraper_obj = item
            return self._evaluate_scraper(module_name, scraper_obj, pack_flags)

        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(_run_one, item): item[0] for item in source_list}
            for future in as_completed(futures):
                module_name = futures[future]
                try:
                    result = future.result()
                except Exception as exc:
                    c.log(f'[ScraperTest] Error testing {module_name}: {exc}', 1)
                    continue

                if result:
                    result['user_disabled'] = user_disabled_map.get(
                        result['module'],
                        int(result.get('user_disabled', 0)),
                    )
                    results.append(result)

                completed += 1
                if progress_callback:
                    label = result['name'] if result else module_name
                    if not progress_callback(completed, total, label):
                        c.log('[ScraperTest] Test cancelled by user')
                        cancelled = True
                        for pending in futures:
                            pending.cancel()
                        break

        if results:
            self._persist_results(results, user_disabled_map, current_time)

        organized = self._organize_results(results, current_time)
        summary = organized['summary']
        c.log(
            f'[ScraperTest] Testing complete ({workers} workers'
            f'{", cancelled" if cancelled else ""}): '
            f'{summary.get("working", 0)} working, '
            f'{summary.get("accessible", 0)} accessible, '
            f'{summary.get("blocked", 0)} blocked, '
            f'{summary.get("disabled", 0)} disabled, '
            f'{summary.get("user_disabled", 0)} user-disabled'
        )

        try:
            from resources.lib.modules.scraper_registry import get_registry
            get_registry().invalidate()
            get_registry().load(force=True)
        except Exception:
            pass

        return organized

    def _test_scraper_connectivity(self, scraper_obj, name):
        """
        Test if a scraper's domain is accessible.

        :return: (accessible, working, response_time, error)
        """
        try:
            # Get domain from scraper
            domains = getattr(scraper_obj, 'domains', [])
            base_link = getattr(scraper_obj, 'base_link', None)
            search_link = getattr(scraper_obj, 'search_link', None)

            # Extract base domain
            test_url = None
            if domains and len(domains) > 0:
                test_url = f"https://{domains[0]}"
            elif base_link:
                test_url = base_link
            else:
                return False, False, None, 'No domain configured'

            # If scraper has a search endpoint, use that instead of just the base
            # (Some sites block base domain but API endpoints work fine - e.g., apibay.org)
            if search_link:
                try:
                    # Build a test search URL
                    from urllib.parse import urljoin, quote_plus
                    if '%s' in search_link:
                        # Replace %s with a simple test query
                        test_search = search_link % quote_plus('test')
                    else:
                        test_search = search_link
                    test_url = urljoin(test_url, test_search)
                    c.log(f'[ScraperTest] Using search endpoint for {name}: {test_url}')
                except Exception as e:
                    c.log(f'[ScraperTest] Could not build search URL, using base: {e}')

            # Test HTTP connectivity
            c.log(f'[ScraperTest] Testing {name}: {test_url}')
            start_time = time.time()
            try:
                # Use longer timeout (20 seconds) for better reliability
                result = client.request(test_url, timeout=20, output='response')
                response_time = time.time() - start_time

                if result:
                    status_code = result.status_code if hasattr(result, 'status_code') else 200
                    c.log(f'[ScraperTest] {name} returned HTTP {status_code} ({response_time:.2f}s)')

                    if status_code < 400:
                        # Site is accessible and working
                        return True, True, response_time, None
                    elif status_code in [403, 451]:
                        # Site exists but geo-blocked - mark as accessible
                        return True, False, response_time, f'HTTP {status_code} - Possibly geo-blocked'
                    elif status_code in [503, 429]:
                        # Site exists but rate limited - mark as accessible
                        return True, False, response_time, f'HTTP {status_code} - Rate limited'
                    else:
                        return True, False, response_time, f'HTTP {status_code}'
                else:
                    c.log(f'[ScraperTest] {name} returned no response')
                    return False, False, None, 'No response'

            except Exception as req_error:
                error_msg = str(req_error)
                c.log(f'[ScraperTest] {name} request error: {error_msg[:100]}')

                # Categorize errors - Be more lenient with CloudFlare/SSL issues
                if 'timeout' in error_msg.lower():
                    return False, False, None, 'Connection timeout'
                elif 'cloudflare' in error_msg.lower() or 'cf-ray' in error_msg.lower():
                    # CloudFlare challenge - site is accessible, just protected
                    return True, False, None, 'CloudFlare protected'
                elif 'ssl' in error_msg.lower() or 'certificate' in error_msg.lower():
                    # SSL errors often mean site is accessible, just cert issues
                    return True, False, None, 'SSL/Certificate issue'
                elif 'blocked' in error_msg.lower() or '403' in error_msg:
                    # Explicitly blocked but site exists
                    return True, False, None, 'Access blocked'
                elif 'connection refused' in error_msg.lower():
                    return False, False, None, 'Connection refused'
                elif 'name or service not known' in error_msg.lower() or 'getaddrinfo failed' in error_msg.lower():
                    return False, False, None, 'DNS resolution failed'
                else:
                    # Unknown error - mark as inaccessible
                    return False, False, None, f'Error: {error_msg[:50]}'

        except Exception as e:
            c.log(f'[ScraperTest] Error testing {name}: {e}', 1)
            return False, False, None, f'Test error: {str(e)[:50]}'

    def clear_cache(self):
        """Clear all cached scraper test results."""
        try:
            dbcon = database.connect(self.cache_file)
            dbcur = dbcon.cursor()
            dbcur.execute('DELETE FROM scraper_status')
            dbcon.commit()
            dbcur.close()
            dbcon.close()
            c.log('[ScraperTest] Cache cleared')
            try:
                from resources.lib.modules.scraper_registry import get_registry
                get_registry().invalidate()
            except Exception:
                pass
            return True
        except Exception as e:
            c.log(f'[ScraperTest] Error clearing cache: {e}', 1)
            return False
