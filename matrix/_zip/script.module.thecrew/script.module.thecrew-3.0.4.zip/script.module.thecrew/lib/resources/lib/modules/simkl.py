# -*- coding: utf-8 -*-

'''
 ***********************************************************
 * The Crew Add-on
 *
 *
 * @file simkl.py
 * @package script.module.thecrew
 *
 * @copyright (c) 2026, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 * Simkl module — credential helpers, PIN auth dialog, scrobble helpers.
 * Analog to trakt.py but for Simkl.
 *
 * Tokens NEVER expire — no token refresh needed.
 *
 ********************************************************cm*
'''

import time
import traceback

from .crewruntime import c
from . import keys
from . import control

# -------------------------------------------------------------------
# Constants
# -------------------------------------------------------------------
BASE_URL = 'https://api.simkl.com'
PIN_POLL_URL = BASE_URL + '/oauth/pin/{user_code}'
PIN_REQUEST_URL = BASE_URL + '/oauth/pin'

# Required query params — must appear on every Simkl API request
# https://simkl.docs.apiary.io/#introduction/required-query-parameters
_APP_NAME = 'TheCrew'
_APP_VERSION = '2.6.21'
_USER_AGENT = f'TheCrew/{_APP_VERSION} Kodi'


def _get_client_id() -> str:
    """
    Return the active Simkl client_id.
    User-supplied value (simkl.client_id setting) takes priority over the
    built-in key — lets users register their own free app at
    https://simkl.com/settings/developer/new/ to avoid the shared daily limit
    while The Crew awaits production approval from Simkl.
    """
    try:
        override = c.get_setting('simkl.client_id') or ''
        if override.strip():
            return override.strip()
    except Exception:
        pass
    return keys.simkl_id


def _required_params() -> dict:
    return {
        'client_id': _get_client_id(),
        'app-name': _APP_NAME,
        'app-version': _APP_VERSION,
    }


# -------------------------------------------------------------------
# Credential helpers
# -------------------------------------------------------------------

def get_simkl_credentials_info() -> bool:
    """
    Return True if a Simkl access token is stored in settings.
    Parallel to trakt.get_trakt_credentials_info().
    """
    try:
        token = c.get_setting('simkl.token') or ''
        return bool(token.strip())
    except Exception:
        return False


def get_simkl_username() -> str:
    """Return stored Simkl username, or empty string."""
    try:
        return (c.get_setting('simkl.user') or '').strip()
    except Exception:
        return ''


def get_tracker_service() -> int:
    """
    Return the selected tracker service from settings.
        0 = Trakt only  (default)
        1 = Simkl only
        2 = Both
    """
    try:
        return int(c.get_setting('tracker.service') or 0)
    except Exception:
        return 0


def use_simkl_tracker() -> bool:
    """Return True if Simkl is enabled as tracker (service = 1 or 2)."""
    return get_tracker_service() in (1, 2)


def use_trakt_tracker() -> bool:
    """Return True if Trakt is still enabled (service = 0 or 2)."""
    return get_tracker_service() in (0, 2)


def is_simkl_scrobble_enabled() -> bool:
    """Return True if Simkl scrobble is on and user is authenticated."""
    try:
        if not get_simkl_credentials_info():
            return False
        scrobble = c.get_setting('simkl.scrobble') or 'false'
        return scrobble.lower() == 'true' and use_simkl_tracker()
    except Exception:
        return False


def set_simkl_credentials(token: str, username: str = ''):
    """Save Simkl token + username to Kodi settings."""
    c.set_setting('simkl.token', token)
    c.set_setting('simkl.user', username)


# -------------------------------------------------------------------
# PIN device flow — Kodi dialog
# -------------------------------------------------------------------

def show_simkl_pin_dialog(verification_url: str, user_code: str,
                          qr_path: str, interval: int, expires_in: int):
    """
    Show QR code dialog for Simkl PIN authentication and poll until token.

    Polls: GET https://api.simkl.com/oauth/pin/{user_code}?client_id={CLIENT_ID}
    Response when approved: {"result": "OK", "access_token": "..."}
    Response when pending:  {"result": "pending"}
    Response when expired:  {"result": "expired"}

    Re-uses the LogViewer_QR.xml dialog from script.thecrew.artwork.

    Args:
        verification_url: Full URL user visits (https://simkl.com/pin/USERCODE)
        user_code:        PIN code to display
        qr_path:          Local path to QR image file (or None)
        interval:         Polling interval in seconds
        expires_in:       Seconds until PIN expires

    Returns:
        (bool, str): (success, access_token) — token is '' on failure
    """
    try:
        import xbmcgui
        import threading

        poll_url = PIN_POLL_URL.format(user_code=user_code)
        # Polling uses GET — include required params (no throttle needed for GET)
        poll_params = {**_required_params()}  # copy so we don't mutate

        class SimklPINViewer(xbmcgui.WindowXMLDialog):

            def __init__(self, *args, **kwargs):
                self.header = kwargs.get('header', 'Simkl Authorization')
                self.message = kwargs.get('message', '')
                self.qr_path = kwargs.get('qr_path', '') or ''
                self.interval = kwargs.get('interval', 5)
                self.expires_in = kwargs.get('expires_in', 600)
                self.authenticated = False
                self.access_token = ''
                self.polling = True
                self.poll_thread = None

            def onInit(self):
                try:
                    HEADERLABEL = 101
                    TEXT = 502
                    QR_IMAGE = 501
                    CLOSEBUTTON = 503

                    self.getControl(HEADERLABEL).setLabel(self.header)
                    self.getControl(TEXT).setText(self.message)

                    if self.qr_path:
                        self.getControl(QR_IMAGE).setImage(self.qr_path)

                    self.setFocusId(CLOSEBUTTON)

                    self.poll_thread = threading.Thread(target=self._poll_for_token)
                    self.poll_thread.daemon = True
                    self.poll_thread.start()

                except Exception as e:
                    c.log(f'[Simkl PIN] onInit error: {e}', 1)

            def _poll_for_token(self):
                """Poll GET /oauth/pin/{user_code} until token or timeout."""
                try:
                    from . import http_client
                    session = http_client.get_session()

                    start_time = time.time()
                    while self.polling and (time.time() - start_time) < self.expires_in:
                        time.sleep(self.interval)
                        try:
                            resp = session.get(poll_url, params=poll_params,
                                               headers={'User-Agent': _USER_AGENT},
                                               timeout=10)
                            if resp.status_code == 200:
                                data = resp.json()
                                if data.get('result') == 'OK':
                                    token = data.get('access_token', '')
                                    if token:
                                        self.authenticated = True
                                        self.access_token = token
                                        self.close()
                                        return
                                elif data.get('result') == 'expired':
                                    c.log('[Simkl PIN] PIN expired', 1)
                                    self.close()
                                    return
                            # 400 / "pending" = still waiting, keep polling
                        except Exception as poll_err:
                            c.log(f'[Simkl PIN] Poll request error: {poll_err}', 1)

                    if self.polling:
                        c.log('[Simkl PIN] Polling timed out', 1)
                        self.close()

                except Exception as e:
                    c.log(f'[Simkl PIN] Polling thread error: {e}', 1)

            def onAction(self, action):
                if action.getId() in [10, 92]:  # NAV_BACK, PREVIOUS_MENU
                    self.polling = False
                    self.close()

            def onClick(self, controlId):
                if controlId == 503:  # Close button
                    self.polling = False
                    self.close()

        xml_file = 'LogViewer_QR.xml'
        addon_path = c.get_artwork_path()
        skin = c.appearance() or 'thecrew'

        message = (
            f'Scan QR code with your mobile device\n\n'
            f'OR visit:\n{verification_url}\n\n'
            f'Waiting for authorization... (expires in {expires_in}s)'
        )

        dialog = SimklPINViewer(
            xml_file,
            addon_path,
            skin,
            '1080i',
            header='Simkl Authorization',
            message=message,
            qr_path=qr_path or '',
            interval=interval,
            expires_in=expires_in
        )
        dialog.doModal()

        authenticated = dialog.authenticated
        access_token = dialog.access_token
        dialog.polling = False
        del dialog

        return authenticated, access_token

    except Exception as e:
        c.log(f'[Simkl PIN] Dialog error: {e}', 1)
        c.log(traceback.format_exc(), 1)
        return False, ''


# -------------------------------------------------------------------
# Auth entry points (called from crew.py router)
# -------------------------------------------------------------------

def auth_simkl():
    """
    Full Simkl PIN authorization flow.
    Entry point for action=authSimkl in crew.py.

    1. POST /oauth/pin to get user_code
    2. Show QR dialog + poll
    3. GET /users/settings to fetch username
    4. Save token + username
    """
    try:
        if get_simkl_credentials_info():
            username = get_simkl_username()
            prompt = f'Simkl account [{username}] already authorized.\n\nRe-authorize?'
            if not c.yesnoDialog(prompt, 'Simkl'):
                return
            set_simkl_credentials('', '')

        from . import http_client
        session = http_client.get_session()

        # Step 1: request PIN
        c.log('[Simkl Auth] Requesting PIN...', 1)
        client_id = _get_client_id()
        if not client_id:
            c.infoDialog(
                'No Simkl Client ID configured.\n\n'
                'Add your Client ID in Settings > API Keys > Simkl Client ID.\n'
                'Register free at simkl.com/settings/developer/new',
                heading='Simkl', sound=True)
            return
        pin_resp = session.post(PIN_REQUEST_URL, params={'client_id': client_id},
                                headers={'User-Agent': _USER_AGENT},
                                json={}, timeout=30)

        if pin_resp.status_code != 200:
            c.log(f'[Simkl Auth] PIN request failed: {pin_resp.status_code}', 1)
            c.infoDialog('Failed to connect to Simkl. Check your internet connection.',
                         heading='Simkl', sound=True)
            return

        pin_data = pin_resp.json()
        user_code = pin_data.get('user_code', '')
        expires_in = int(pin_data.get('expires_in', 600))
        interval = int(pin_data.get('interval', 5))

        if not user_code:
            c.log('[Simkl Auth] No user_code in response', 1)
            c.infoDialog('Simkl returned an invalid response.', heading='Simkl', sound=True)
            return

        pin_url = f'https://simkl.com/pin/{user_code}'
        c.log(f'[Simkl Auth] user_code={user_code}, url={pin_url}', 1)

        # Step 2: generate QR
        qr_path = None
        try:
            from . import utils
            qr_path = utils.make_qrcode(pin_url, 'simkl_auth.png')
        except Exception as qr_err:
            c.log(f'[Simkl Auth] QR generation failed (non-fatal): {qr_err}', 1)

        # Step 3: show QR dialog + poll
        authenticated, access_token = show_simkl_pin_dialog(
            verification_url=pin_url,
            user_code=user_code,
            qr_path=qr_path,
            interval=interval,
            expires_in=expires_in
        )

        if not authenticated or not access_token:
            c.log('[Simkl Auth] Authorization failed or timed out', 1)
            c.infoDialog('Simkl authorization failed or timed out.', heading='Simkl', sound=True)
            return

        # Step 4: fetch username
        username = _fetch_username(session, access_token)

        # Step 5: save
        set_simkl_credentials(access_token, username)
        c.log(f'[Simkl Auth] Authorized as: {username}', 1)
        c.infoDialog(f'Simkl authorized{": " + username if username else ""}',
                     heading='Simkl', sound=False)

    except Exception as e:
        c.log(f'[Simkl Auth] Exception: {e}', 1)
        c.log(traceback.format_exc(), 1)
        control.openSettings('3.1')


def revoke_simkl():
    """
    Clear stored Simkl credentials.
    Entry point for action=revokeSimkl in crew.py.

    Simkl has no API revoke endpoint — clearing locally is sufficient.
    """
    try:
        if not get_simkl_credentials_info():
            c.infoDialog('No Simkl account is authorized.', heading='Simkl', sound=False)
            return

        username = get_simkl_username()
        if c.yesnoDialog(
            f'Remove Simkl authorization{" for " + username if username else ""}?',
            'Simkl'
        ):
            set_simkl_credentials('', '')
            c.log('[Simkl Auth] Authorization revoked', 1)
            c.infoDialog('Simkl authorization removed.', heading='Simkl', sound=False)
    except Exception as e:
        c.log(f'[Simkl Auth] revoke_simkl error: {e}', 1)


# -------------------------------------------------------------------
# Internal helpers
# -------------------------------------------------------------------

def _fetch_username(session, token: str) -> str:
    """
    GET /users/settings with given token to retrieve username.
    Returns 'simkl_user' as fallback.
    """
    try:
        headers = {
            'Content-Type': 'application/json',
            'simkl-api-key': CLIENT_ID,
            'Authorization': f'Bearer {token}',
            'User-Agent': _USER_AGENT,
        }
        resp = session.get(f'{BASE_URL}/users/settings',
                           headers=headers,
                           params=_required_params(),
                           timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            return data.get('user', {}).get('username', 'simkl_user')
    except Exception as e:
        c.log(f'[Simkl] _fetch_username error: {e}', 1)
    return 'simkl_user'


# -------------------------------------------------------------------
# Scrobble helpers (Phase 2 — called from process_scrobble_queue)
# -------------------------------------------------------------------

def simkl_scrobble_movie(imdb: str, title: str, year: int,
                         progress: float, action: str = 'stop'):
    """
    Send a movie scrobble event to Simkl.

    Args:
        imdb:     IMDb ID (e.g. 'tt1375666')
        title:    Movie title (for fallback matching)
        year:     Release year
        progress: Playback percentage 0–100
        action:   'start', 'pause', or 'stop'
    """
    if not is_simkl_scrobble_enabled():
        return

    try:
        from ..apis.simkl_api import SimklAPI
        api = SimklAPI()
        movie_obj = {'movie': SimklAPI.build_movie_obj(title=title, year=year, imdb=imdb)}

        if action == 'start':
            api.scrobble_start(movie_obj, progress)
        elif action == 'pause':
            api.scrobble_pause(movie_obj, progress)
        else:
            api.scrobble_stop(movie_obj, progress)

        if c.devmode:
            c.log(f'[Simkl Scrobble] Movie {action} — {title} ({year}) @ {progress:.0f}%', 1)

    except Exception as e:
        c.log(f'[Simkl Scrobble] simkl_scrobble_movie error: {e}', 1)


def simkl_scrobble_episode(imdb: str, show_title: str, year: int,
                           season: int, episode: int,
                           progress: float, action: str = 'stop'):
    """
    Send an episode scrobble event to Simkl.

    Args:
        imdb:       Show's IMDb ID (e.g. 'tt0903747')
        show_title: Show name
        year:       Show premiere year
        season:     Season number
        episode:    Episode number
        progress:   Playback percentage 0–100
        action:     'start', 'pause', or 'stop'
    """
    if not is_simkl_scrobble_enabled():
        return

    try:
        from ..apis.simkl_api import SimklAPI
        api = SimklAPI()

        episode_payload = {
            'show': SimklAPI.build_show_obj(title=show_title, year=year, imdb=imdb),
            'episode': {'season': season, 'number': episode},
        }

        if action == 'start':
            api.scrobble_start(episode_payload, progress)
        elif action == 'pause':
            api.scrobble_pause(episode_payload, progress)
        else:
            api.scrobble_stop(episode_payload, progress)

        if c.devmode:
            c.log(f'[Simkl Scrobble] Episode {action} — '
                  f'{show_title} S{season:02d}E{episode:02d} @ {progress:.0f}%', 1)

    except Exception as e:
        c.log(f'[Simkl Scrobble] simkl_scrobble_episode error: {e}', 1)
